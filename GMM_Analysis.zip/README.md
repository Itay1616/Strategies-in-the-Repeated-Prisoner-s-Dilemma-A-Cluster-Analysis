# Gaussian mixture model for the GEB revision

The analysis uses the 1,734 players in the second half of each session. Each player contributes one vector of cooperation frequencies, in the order first round, CC, CD, DC, DD. The first letter in a history is the player's action. The model has five components with separately estimated means and weights and one common covariance matrix of the form s²I. A GMM share is the mean membership probability. A modal assignment is the type with the highest membership probability.

## Reproduce the estimates

Use Python 3.12. From the extracted directory run

    python -m pip install -r requirements.txt
    python fit_gmm.py input/counts.csv reproduced

To use the authors' original workbook directly, run

    python fit_gmm.py "/path/to/two-halves-likelihood.xlsx" reproduced

The input CSV contains the IDs and the five opportunity and cooperation counts from worksheet `1734 חצי שני` of the original workbook. The script uses the observed cooperation rate for each experienced history and the player's overall cooperation rate for an unobserved history. It keeps the original 0–1 scale. The opportunity totals are 18,104, 19,497, 4,584, 4,586, and 22,989, respectively.

The program verifies the reference k-means partition against the 25 history counts in Table 9. It estimates the GMM by maximum likelihood with 200 EM initializations and retains the largest observed likelihood. The starting values use the paper's partition, k-means fits and k-means++ initial centers. Labels are matched to the k-means types after estimation by maximizing assignment overlap. The likelihood concerns the density of player-level profiles.

## Results

The classifications agree for 1,685 of 1,734 players (97.2%). The fitted common variance is 0.03946. In the order AD, STFT, GR, TFT, AC, the estimated shares are 33.8%, 13.3%, 16.4%, 22.1%, and 14.4%.

The results folder contains the model summary (fit.csv), the component shares and centers (profiles.csv), the assignment cross-tabulation (transitions.csv), the player-level profiles and posterior probabilities (assignments.csv), and the likelihood and iteration count of each initialization (starts.csv). The centers average the imputed player-level vectors with posterior weights. The means in Table 9 of the paper pool choices among hard-assigned players and weight experienced histories by their observed frequency.
