"""Fit the five-component IRPD Gaussian mixture and compare with paper k-means."""
import argparse
import csv
from pathlib import Path

import numpy as np
from openpyxl import load_workbook
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist
from scipy.special import logsumexp
from sklearn.cluster import KMeans, kmeans_plusplus
from sklearn.metrics import confusion_matrix
from threadpoolctl import threadpool_limits

HISTORIES = ["First", "CC", "CD", "DC", "DD"]
TYPES = np.array(["AD", "STFT", "GR", "TFT", "AC"])
# Each row is one cluster in the paper's Table 9. Each column is a history.
PAPER_COUNTS = np.array([[6488, 67, 345, 1819, 12224], [2762, 1900, 911, 988, 4029],
                         [2779, 3762, 976, 847, 3569], [3982, 7017, 1860, 700, 3077],
                         [2093, 6751, 492, 232, 90]])


def read_profiles(source):
    if source.suffix.lower() == ".csv":
        rows = np.loadtxt(source, delimiter=",", skiprows=1, dtype=int)
    else:
        workbook = load_workbook(source, read_only=True, data_only=True)
        sheet = workbook["1734 חצי שני"]
        rows = []
        for row in sheet.iter_rows(min_row=5, max_col=22, values_only=True):
            if row[0] is None:
                continue
            counts = np.array([int(value or 0) for value in row[1:6]])
            successes = counts * [float(value or 0) for value in row[6:11]]
            np.testing.assert_allclose(successes, successes.round(), rtol=0, atol=1e-7)
            assert counts.sum() == row[21]
            rows.append([row[0], *counts, *successes.round().astype(int)])
        workbook.close()
        rows = np.asarray(rows, dtype=int)
    ids, counts, successes = rows[:, 0], rows[:, 1:6], rows[:, 6:11]
    assert len(ids) == len(np.unique(ids)) == 1734
    assert np.all((0 <= successes) & (successes <= counts))
    assert np.all(counts.sum(axis=1) > 0)
    overall = successes.sum(axis=1) / counts.sum(axis=1)
    profiles = np.where(counts > 0, successes / np.maximum(counts, 1), overall[:, None])
    return ids, counts, profiles


def reference_partition(profiles, counts):
    labels = KMeans(n_clusters=5, n_init=1, random_state=283).fit_predict(profiles)
    sizes = np.array([counts[labels == group].sum(axis=0) for group in range(5)])
    _, order = linear_sum_assignment(cdist(PAPER_COUNTS, sizes))
    np.testing.assert_array_equal(sizes[order], PAPER_COUNTS)
    return np.argsort(order)[labels]


def fit_gmm(profiles, initial_labels):
    n, dimensions = profiles.shape
    probabilities = np.eye(5)[initial_labels]
    last_log_likelihood = -np.inf
    for iteration in range(1, 2001):
        sizes = probabilities.sum(axis=0)
        if sizes.min() < 1e-9:
            raise ArithmeticError("Empty component")
        weights = sizes / n
        centers = (probabilities.T @ profiles) / sizes[:, None]
        squared_distances = cdist(profiles, centers, metric="sqeuclidean")
        variance = np.sum(probabilities * squared_distances) / (n * dimensions)
        log_joint = np.log(weights) - squared_distances / (2 * variance)
        log_joint -= dimensions / 2 * np.log(2 * np.pi * variance)
        log_density = logsumexp(log_joint, axis=1)
        log_likelihood = float(log_density.sum())
        probabilities = np.exp(log_joint - log_density[:, None])
        change = log_likelihood - last_log_likelihood
        if change < -1e-7:
            raise ArithmeticError("EM likelihood decreased")
        if change < 1e-10 * n:
            return log_likelihood, weights, centers, variance, probabilities, iteration
        last_log_likelihood = log_likelihood
    raise RuntimeError("EM failed to converge")


def write_csv(path, header, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def run(source, output):
    ids, counts, profiles = read_profiles(source)
    reference = reference_partition(profiles, counts)
    starts = []
    best = None
    for seed in range(200):
        if seed == 0:
            initial = reference
        elif seed % 2:
            initial = KMeans(n_clusters=5, n_init=1, random_state=seed).fit_predict(profiles)
        else:
            centers, _ = kmeans_plusplus(profiles, n_clusters=5, random_state=seed)
            initial = cdist(profiles, centers).argmin(axis=1)
        fit = fit_gmm(profiles, initial)
        starts.append([seed, fit[0], fit[-1]])
        if best is None or fit[0] > best[0]:
            best = fit
    ll, weights, centers, variance, probabilities, _ = best
    # Align arbitrary component names by maximizing agreement after estimation.
    cross_tab = confusion_matrix(reference, probabilities.argmax(axis=1), labels=range(5))
    _, order = linear_sum_assignment(-cross_tab)
    weights, centers, probabilities = weights[order], centers[order], probabilities[:, order]
    modal = probabilities.argmax(axis=1)
    matches = np.count_nonzero(reference == modal)
    assert np.allclose(probabilities.sum(axis=1), 1)
    assert np.allclose(probabilities.mean(axis=0), weights, atol=1e-5)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "fit.csv",
              ["Model", "Players", "Agreement count", "Agreement share", "Profile log-likelihood",
               "Common variance", "Largest posterior below 0.8", "Starts"],
              [["GMM", len(ids), matches, matches / len(ids), ll, variance,
                np.count_nonzero(probabilities.max(axis=1) < .8), len(starts)]])
    write_csv(output / "profiles.csv",
              ["Type", "K-means count", "K-means share", "GMM weight", "GMM modal count", *HISTORIES],
              [[name, (reference == j).sum(), (reference == j).mean(), weights[j],
                (modal == j).sum(), *centers[j]] for j, name in enumerate(TYPES)])
    write_csv(output / "assignments.csv",
              ["ID", *HISTORIES, "K-means type", "GMM type", *["Pr " + name for name in TYPES]],
              zip(ids, *profiles.T, TYPES[reference], TYPES[modal], *probabilities.T))
    write_csv(output / "transitions.csv", ["K-means type / GMM type", *TYPES],
              [[name, *row] for name, row in zip(TYPES, cross_tab[:, order])])
    write_csv(output / "starts.csv", ["Seed", "Profile log-likelihood", "Iterations"], starts)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="input/counts.csv or the authors' original .xlsx")
    parser.add_argument("output", type=Path, help="directory for the result tables")
    args = parser.parse_args()
    with threadpool_limits(limits=1):
        run(args.source, args.output)
